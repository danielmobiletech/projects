#include "PhoneBook.h"
#include <iostream>
#include <string>
#include<cctype>
using namespace std;
PhoneBookItem::PhoneBookItem(const string& name, int age, const string& phone, PhoneBookItem* next = NULL)
	: m_name(name), m_age(age),m_phone(phone), m_next(next)
{}
ostream& operator<< (ostream& os, const PhoneBookItem& n) // cout << n;
{
	os << "Name: " << n.m_name << "\tAge: " << n.m_age<<"\tPhoneNumber: "<<n.m_phone;
	return os;
}
PhoneBook::PhoneBook()
	: m_head(new PhoneBookItem("", -99,"", NULL)), m_num(0)
{}
//
PhoneBook::PhoneBook(const PhoneBook& existingList)
{
	Copy(existingList);
}
void PhoneBook::Copy(const PhoneBook& existingList)
{
	m_num = existingList.m_num;
	m_head = new PhoneBookItem("", -99,"", NULL); // create "Dummy PhoneBookItem"
	PhoneBookItem *p = existingList.m_head->m_next;
	PhoneBookItem *pThis = m_head;
	while (p != 0) // loop through existingList
	{
		pThis->m_next = new PhoneBookItem(p->m_name, p->m_age,p->m_phone, 0);
		// update p AND pThis
		p = p->m_next;
		pThis = pThis->m_next;
	}
}
PhoneBook::~PhoneBook()
{
	Clear();
}
void PhoneBook::Clear()
{
	PhoneBookItem *p = m_head;
	PhoneBookItem *save;
	while (p != 0)
	{
		save = p->m_next;
		delete p;
		p = save;
	}
}
// why &??
PhoneBook& PhoneBook::operator =(const PhoneBook& list2) // list1 = list2;
{
	if (this != &list2) // check for self-assignment --> list2 = list2;
	{
		// cleanup list1
		this->Clear();
		// copy over list2
		this->Copy(list2);
	}
	// return the value that was assigned
	return *this;
}
bool PhoneBook::IsEmpty() const
{
	return m_num == 0;
	// OR: return m_head->m_next == NULL;
}
int PhoneBook::Size() const
{
	return m_num;
}
bool PhoneBook::Insert(const string& name, int age, const string& phone)
{
	//if (this!=0)
	PhoneBookItem *p = m_head->m_next;
	PhoneBookItem *tp = m_head;
	while (p != 0)
	{
		//tp = p;
		if (name<p->m_name)
		{
			break;
			
			
		}
		else if (p->m_name == name)
		{
			return false;
		}
		tp->m_next = p;
		p = p->m_next;
		//p = p->m_next;
	}
	tp->m_next = new PhoneBookItem(name, age,phone, tp->m_next);
//	p->m_next = tp;
	this->m_num++;
	return true;
}
ostream& operator<< (ostream& os, const PhoneBook& list) // cout << list;
{
	PhoneBookItem *p = list.m_head->m_next;
	while (p != 0)
	{
		cout << *p << endl;
		// move p to next PhoneBookItem
		p = p->m_next;
	}
	return os;
}
// input: name
// output: age if found
bool PhoneBook::Lookup(const string& name, int& age, const string& phone) const
{
	// linear search
	PhoneBookItem *p = m_head->m_next;
	while (p != 0)
	{
		if (name == p->m_name ||phone==p->m_phone)
		{

			/*age = p->m_age;
			phone = p->m_phone;*/
			return true;
		}
		// update p
		p = p->m_next;
	}
	return false;
}
bool PhoneBook::Delete(const string& name)
{
	PhoneBookItem *p = m_head->m_next;
	PhoneBookItem *tp = m_head; // trail pointer
	while (p != 0)
	{
		if (name.compare(p->m_name)==0)
		{
			// found it, now delete it
			// NOT: tp = p->m_next;
			tp->m_next = p->m_next;
			this->m_num--;
			delete p;
			return true;
		}
		// update pointers
		tp = p->m_next; // tp = tp->m_next;
		p = p->m_next;
	}
	return false;
}