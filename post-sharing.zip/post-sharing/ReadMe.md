This Plugin Posts to facebook when Wordpress post/updated is created also compatible with Woocomerce postings
This plugin also user to post to specific Facebook Pages.
