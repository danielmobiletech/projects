
#pragma once
#include <iostream>
#include <string>
#include<cctype>
using namespace std;

struct PhoneBookItem{
	string m_name; // key
	int m_age;
	string m_phone;
	PhoneBookItem* m_next;
	PhoneBookItem(const string& name, int age, const string& phone, PhoneBookItem* );
	// NULL same as 0, 0 is preferred
};
ostream& operator<< (ostream&, const PhoneBookItem&);
class PhoneBook {
	friend ostream& operator<< (ostream&, const PhoneBook&);
public:
	PhoneBook();
	// copy ctor
	PhoneBook(const PhoneBook& existingList);
	~PhoneBook();
	bool IsEmpty() const;
	int Size() const;
	bool Insert(const string& name, int age, const string& phone);
	bool Delete(const string& name);
	bool Lookup(const string& name, int& age,const string& phone) const;
	PhoneBook& operator=(const PhoneBook& list2);
private:
	PhoneBookItem* m_head; // points to head of the list
	int m_num; // the number of entries in the list
	// IN CLASS EXAMPLE, m_num IS NOT MAINTAINED PROPERLY
	// helper functions:
	void Clear();
	void Copy(const PhoneBook& list2);
};
