#include<iostream>
#include<string>
#include<cctype>
#include"PhoneBook.h"
using namespace std;

void main()
{
	
	PhoneBook l;
	//l.Insert("joses",12,"3122"); // insert 5 or 6 people
	l.Insert("Mosesv", 12, "3122");
	l.Insert("vbsesv", 12, "3122");
	l.Insert("bsesv", 12, "3122");
	l.Insert("absesv", 12, "3122");
	cout << l.Size()<< endl;	
	cout << "Original PhoneBook : " << endl;
	cout << l << endl;
	// test copy ctor
	PhoneBook l2(l);
	cout << "PhoneBook after copy ctor : " << endl;
	cout << l2 << endl;
	// test operator =
	PhoneBook l3;
		l3 = l;
	cout << "PhoneBook after operator= : " << endl;
	cout << l3 << endl;
	// pause, then menu with the rest of main() code
	// �
	cin.get();
	return;
}