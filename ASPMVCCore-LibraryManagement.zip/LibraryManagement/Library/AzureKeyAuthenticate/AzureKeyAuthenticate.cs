﻿using System;

namespace AzureKeyAuthenticate
{
    public class Class1
    {
    }
}
